import { usePasskeyRegister } from '@laravel/passkeys/react';
import { useState } from 'react';
import InputError from '@/components/input-error';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

type Props = {
  onSuccess: () => void;
};

export default function PasskeyRegistration({ onSuccess }: Props) {
  const [name, setName] = useState(() => {
    const ua = navigator.userAgent;

    const browser = ['Chrome', 'Firefox', 'Safari', 'Edge', 'Opera'].find(
      (browser) => new RegExp(browser).test(ua),
    );

    const os = ['iPhone', 'iPad', 'Android', 'Mac', 'Windows'].find((os) =>
      new RegExp(os).test(ua),
    );

    return [browser, os].filter(Boolean).join(' on ') || '';
  });

  const [showForm, setShowForm] = useState(false);
  const { register, isLoading, error, isSupported } = usePasskeyRegister({
    onSuccess: () => {
      setName('');
      setShowForm(false);
      onSuccess();
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      return;
    }

    await register(name);
  };

  const handleCancel = () => {
    setShowForm(false);
    setName('');
  };

  if (!isSupported) {
    return (
      <div className="text-sm text-muted-foreground">
        Passkeys não são suportados neste navegador. Por favor, use um navegador
        compatível para registrar uma passkey.
      </div>
    );
  }

  if (!showForm) {
    return (
      <Button variant="outline" onClick={() => setShowForm(true)}>
        Adicionar passkey
      </Button>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 border border-border bg-muted/50 p-4"
    >
      <div className="grid gap-2">
        <Label htmlFor="passkey-name">Nome da passkey</Label>
        <Input
          id="passkey-name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g., MacBook Pro, iPhone"
          className="mt-1 block w-full border-foreground/20"
          autoFocus
        />
        <p className="text-xs text-muted-foreground">
          Um nome ajuda você a identificar esta passkey posteriormente.
        </p>
      </div>

      {error && <InputError message={error} />}

      <div className="flex gap-2">
        <Button type="submit" disabled={isLoading || !name.trim()}>
          {isLoading ? 'Registrando...' : 'Registrar passkey'}
        </Button>
        <Button type="button" variant="ghost" onClick={handleCancel}>
          Cancelar
        </Button>
      </div>
    </form>
  );
}
