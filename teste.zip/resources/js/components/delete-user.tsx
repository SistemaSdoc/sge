import { Form } from '@inertiajs/react';
import { useRef } from 'react';
import ProfileController from '@/actions/App/Http/Controllers/Settings/ProfileController';
import Heading from '@/components/heading';
import InputError from '@/components/input-error';
import PasswordInput from '@/components/password-input';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

export default function DeleteUser() {
  const passwordInput = useRef<HTMLInputElement>(null);

  return (
    <div className="space-y-6">
      <Heading
        variant="small"
        title="Excluir conta"
        description="Exclua sua conta e todos os seus recursos permanentemente. Por favor, insira sua senha para confirmar que deseja excluir permanentemente sua conta."
      />
      <div className="space-y-4 border border-red-100 bg-red-50 p-4 dark:border-red-200/10 dark:bg-red-700/10">
        <div className="relative space-y-0.5 text-red-600 dark:text-red-100">
          <p className="font-medium">Aviso</p>
          <p className="text-sm">
            Esta ação é permanente e não pode ser desfeita. Por favor, tenha
            certeza de que deseja excluir sua conta antes de prosseguir.
          </p>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button variant="destructive" data-test="delete-user-button">
              Excluir conta
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogTitle>
              Tem certeza de que deseja excluir sua conta?
            </DialogTitle>
            <DialogDescription>
              Esta ação é permanente e não pode ser desfeita. Por favor, insira
              sua senha para confirmar que deseja excluir permanentemente sua
              conta.
            </DialogDescription>

            <Form
              {...ProfileController.destroy.form()}
              options={{
                preserveScroll: true,
              }}
              onError={() => passwordInput.current?.focus()}
              resetOnSuccess
              className="space-y-6"
            >
              {({ resetAndClearErrors, processing, errors }) => (
                <>
                  <div className="grid gap-2">
                    <Label htmlFor="password" className="sr-only">
                      Senha
                    </Label>

                    <PasswordInput
                      id="password"
                      name="password"
                      ref={passwordInput}
                      placeholder="Senha"
                      autoComplete="current-password"
                    />

                    <InputError message={errors.password} />
                  </div>

                  <DialogFooter className="gap-2">
                    <DialogClose asChild>
                      <Button
                        variant="secondary"
                        onClick={() => resetAndClearErrors()}
                      >
                        Cancelar
                      </Button>
                    </DialogClose>

                    <Button variant="destructive" disabled={processing} asChild>
                      <button
                        type="submit"
                        data-test="confirm-delete-user-button"
                      >
                        Excluir conta
                      </button>
                    </Button>
                  </DialogFooter>
                </>
              )}
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
