import google from './google'
import facebook from './facebook'

const auth = {
    google: Object.assign(google, google),
    facebook: Object.assign(facebook, facebook),
}

export default auth