import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
export const redirect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/auth/facebook/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
redirect.url = (options?: RouteQueryOptions) => {
    return redirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
redirect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
redirect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
const redirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
redirectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::redirect
* @see app/Http/Controllers/Auth/FacebookAuthController.php:15
* @route '/auth/facebook/redirect'
*/
redirectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirect.form = redirectForm

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/auth/facebook/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\FacebookAuthController::callback
* @see app/Http/Controllers/Auth/FacebookAuthController.php:26
* @route '/auth/facebook/callback'
*/
callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback.form = callbackForm

const facebook = {
    redirect: Object.assign(redirect, redirect),
    callback: Object.assign(callback, callback),
}

export default facebook