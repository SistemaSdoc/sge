import { Form, Head } from '@inertiajs/react';
import { useState } from 'react';
import { GoogleButton } from '@/components/google-button';
import InputError from '@/components/input-error';
import PasswordInput from '@/components/password-input';
import TextLink from '@/components/text-link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { login } from '@/routes';
import { redirect } from '@/routes/auth/google';
import { store } from '@/routes/register';

type Props = {
  passwordRules: string;
};

export default function Register({ passwordRules }: Props) {
  const [googleLoading, setGoogleLoading] = useState(false);

  const handleGoogleRegister = () => {
    setGoogleLoading(true);
    window.location.href = redirect().url;
  };

  return (
    <>
      <Head title="Register" />

      <div className="flex flex-col gap-6">
        <GoogleButton
          isLoading={googleLoading}
          onClick={handleGoogleRegister}
          disabled={googleLoading}
        />

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border border-t border-border" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="bg-background px-2 text-muted-foreground">
              Ou continuar com email
            </span>
          </div>
        </div>
      </div>

      <Form
        {...store.form()}
        resetOnSuccess={['password', 'password_confirmation']}
        disableWhileProcessing
        className="flex flex-col gap-6"
      >
        {({ processing, errors }) => (
          <>
            <div className="grid gap-6">
              <div className="grid gap-2">
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  type="text"
                  required
                  autoFocus
                  tabIndex={1}
                  autoComplete="name"
                  name="name"
                  placeholder="Nome completo"
                />
                <InputError message={errors.name} className="mt-2" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="email">Endereço de Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  tabIndex={2}
                  autoComplete="email"
                  name="email"
                  placeholder="email@exemplo.com"
                />
                <InputError message={errors.email} />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="password">Senha</Label>
                <PasswordInput
                  id="password"
                  required
                  tabIndex={3}
                  autoComplete="new-password"
                  name="password"
                  placeholder="Senha"
                  passwordrules={passwordRules}
                />
                <InputError message={errors.password} />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="password_confirmation">Confirmar senha</Label>
                <PasswordInput
                  id="password_confirmation"
                  required
                  tabIndex={4}
                  autoComplete="new-password"
                  name="password_confirmation"
                  placeholder="Confirmar senha"
                  passwordrules={passwordRules}
                />
                <InputError message={errors.password_confirmation} />
              </div>

              <Button
                type="submit"
                className="mt-2 w-full"
                tabIndex={5}
                data-test="register-user-button"
              >
                {processing && <Spinner />}
                Criar conta
              </Button>
            </div>

            <div className="text-center text-sm text-muted-foreground">
              Já tem uma conta?{' '}
              <TextLink href={login().url} tabIndex={6}>
                Entrar
              </TextLink>
            </div>
          </>
        )}
      </Form>
    </>
  );
}

Register.layout = {
  title: 'Criar uma conta',
  description:
    'Insira seus dados abaixo para criar sua conta ou continue com Google',
};
