import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
export const redirect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/password-confirmation/google/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
redirect.url = (options?: RouteQueryOptions) => {
    return redirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
redirect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
redirect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
const redirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
redirectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::redirect
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:17
* @route '/password-confirmation/google/redirect'
*/
redirectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirect.form = redirectForm

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/password-confirmation/google/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PasswordConfirmationGoogleController::callback
* @see app/Http/Controllers/Auth/PasswordConfirmationGoogleController.php:25
* @route '/password-confirmation/google/callback'
*/
callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback.form = callbackForm

const PasswordConfirmationGoogleController = { redirect, callback }

export default PasswordConfirmationGoogleController