import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
const redirecta9f4d253cf7aa92a3a3e9c6102587ff9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url(options),
    method: 'get',
})

redirecta9f4d253cf7aa92a3a3e9c6102587ff9.definition = {
    methods: ["get","head"],
    url: '/google/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url = (options?: RouteQueryOptions) => {
    return redirecta9f4d253cf7aa92a3a3e9c6102587ff9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
redirecta9f4d253cf7aa92a3a3e9c6102587ff9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
redirecta9f4d253cf7aa92a3a3e9c6102587ff9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
const redirecta9f4d253cf7aa92a3a3e9c6102587ff9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
redirecta9f4d253cf7aa92a3a3e9c6102587ff9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/google/redirect'
*/
redirecta9f4d253cf7aa92a3a3e9c6102587ff9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecta9f4d253cf7aa92a3a3e9c6102587ff9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirecta9f4d253cf7aa92a3a3e9c6102587ff9.form = redirecta9f4d253cf7aa92a3a3e9c6102587ff9Form
/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
const redirecte095232accdfa54b25959e07da13dad7 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirecte095232accdfa54b25959e07da13dad7.url(options),
    method: 'get',
})

redirecte095232accdfa54b25959e07da13dad7.definition = {
    methods: ["get","head"],
    url: '/auth/google/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
redirecte095232accdfa54b25959e07da13dad7.url = (options?: RouteQueryOptions) => {
    return redirecte095232accdfa54b25959e07da13dad7.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
redirecte095232accdfa54b25959e07da13dad7.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirecte095232accdfa54b25959e07da13dad7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
redirecte095232accdfa54b25959e07da13dad7.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirecte095232accdfa54b25959e07da13dad7.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
const redirecte095232accdfa54b25959e07da13dad7Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecte095232accdfa54b25959e07da13dad7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
redirecte095232accdfa54b25959e07da13dad7Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecte095232accdfa54b25959e07da13dad7.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::redirect
* @see app/Http/Controllers/Auth/GoogleAuthController.php:14
* @route '/auth/google/redirect'
*/
redirecte095232accdfa54b25959e07da13dad7Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirecte095232accdfa54b25959e07da13dad7.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirecte095232accdfa54b25959e07da13dad7.form = redirecte095232accdfa54b25959e07da13dad7Form

/**
* Multiple routes resolve to \App\Http\Controllers\Auth\GoogleAuthController::redirect, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `redirect['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const redirect = {
    '/google/redirect': redirecta9f4d253cf7aa92a3a3e9c6102587ff9,
    '/auth/google/redirect': redirecte095232accdfa54b25959e07da13dad7,
}

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
const callbackdb9f099626d2ce3fba58b0b29a9dd0ae = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url(options),
    method: 'get',
})

callbackdb9f099626d2ce3fba58b0b29a9dd0ae.definition = {
    methods: ["get","head"],
    url: '/google/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url = (options?: RouteQueryOptions) => {
    return callbackdb9f099626d2ce3fba58b0b29a9dd0ae.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
callbackdb9f099626d2ce3fba58b0b29a9dd0ae.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
callbackdb9f099626d2ce3fba58b0b29a9dd0ae.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
const callbackdb9f099626d2ce3fba58b0b29a9dd0aeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
callbackdb9f099626d2ce3fba58b0b29a9dd0aeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/google/callback'
*/
callbackdb9f099626d2ce3fba58b0b29a9dd0aeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callbackdb9f099626d2ce3fba58b0b29a9dd0ae.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callbackdb9f099626d2ce3fba58b0b29a9dd0ae.form = callbackdb9f099626d2ce3fba58b0b29a9dd0aeForm
/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
const callback6f943d0bcf198213e37681229483d721 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback6f943d0bcf198213e37681229483d721.url(options),
    method: 'get',
})

callback6f943d0bcf198213e37681229483d721.definition = {
    methods: ["get","head"],
    url: '/auth/google/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
callback6f943d0bcf198213e37681229483d721.url = (options?: RouteQueryOptions) => {
    return callback6f943d0bcf198213e37681229483d721.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
callback6f943d0bcf198213e37681229483d721.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback6f943d0bcf198213e37681229483d721.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
callback6f943d0bcf198213e37681229483d721.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback6f943d0bcf198213e37681229483d721.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
const callback6f943d0bcf198213e37681229483d721Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback6f943d0bcf198213e37681229483d721.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
callback6f943d0bcf198213e37681229483d721Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback6f943d0bcf198213e37681229483d721.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\GoogleAuthController::callback
* @see app/Http/Controllers/Auth/GoogleAuthController.php:19
* @route '/auth/google/callback'
*/
callback6f943d0bcf198213e37681229483d721Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback6f943d0bcf198213e37681229483d721.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback6f943d0bcf198213e37681229483d721.form = callback6f943d0bcf198213e37681229483d721Form

/**
* Multiple routes resolve to \App\Http\Controllers\Auth\GoogleAuthController::callback, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `callback['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const callback = {
    '/google/callback': callbackdb9f099626d2ce3fba58b0b29a9dd0ae,
    '/auth/google/callback': callback6f943d0bcf198213e37681229483d721,
}

const GoogleAuthController = { redirect, callback }

export default GoogleAuthController