import GoogleAuthController from './GoogleAuthController'
import FacebookAuthController from './FacebookAuthController'
import PasswordConfirmationGoogleController from './PasswordConfirmationGoogleController'

const Auth = {
    GoogleAuthController: Object.assign(GoogleAuthController, GoogleAuthController),
    FacebookAuthController: Object.assign(FacebookAuthController, FacebookAuthController),
    PasswordConfirmationGoogleController: Object.assign(PasswordConfirmationGoogleController, PasswordConfirmationGoogleController),
}

export default Auth