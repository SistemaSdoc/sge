<?php echo e($slot); ?>

<?php /**PATH /home/marq/test-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>